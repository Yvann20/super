import os
import asyncio
import nest_asyncio
import re
import time
import psutil
import mercadopago
from pathlib import Path
from datetime import datetime, timedelta
from dotenv import load_dotenv
from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup
)
from telegram.ext import (
    ApplicationBuilder, ContextTypes, CommandHandler, CallbackQueryHandler,
    ConversationHandler, MessageHandler, filters, JobQueue
)
from telethon import TelegramClient
from telethon.errors import (
    SessionPasswordNeededError, PhoneCodeInvalidError, PhoneNumberBannedError,
    MessageIdInvalidError, ChatAdminRequiredError, FloodWaitError
)
from telethon.tl.types import ChannelParticipantsAdmins

from prometheus_client import start_http_server, Counter, Gauge, Summary
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import Column, Integer, BigInteger, String, DateTime, Boolean, ForeignKey, select, func, UniqueConstraint, Date

nest_asyncio.apply()

# ==================== CONFIG & ENV =====================

load_dotenv()
BOT_TOKEN = os.environ.get("BOT_TOKEN")
DATABASE_URL = os.environ.get("DATABASE_URL", "sqlite+aiosqlite:///./meubanco.db")
MENU_IMAGE_URL = os.environ.get("MENU_IMAGE_URL", "https://i.imgur.com/8Q2Q5Qp.png")
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))
SUPORTE_LINK = os.environ.get("SUPORTE_LINK", "https://t.me/SEU_SUPORTE")
ADMIN_USERNAME = os.environ.get("ADMIN_USERNAME", "@SEU_ADMIN")
MP_ACCESS_TOKEN = os.environ.get("MP_ACCESS_TOKEN")
SESSIONS_DIR = Path('sessions')
SESSIONS_DIR.mkdir(exist_ok=True)

if not (BOT_TOKEN and MENU_IMAGE_URL and OWNER_ID and MP_ACCESS_TOKEN):
    raise ValueError('Configure BOT_TOKEN, MENU_IMAGE_URL, OWNER_ID e MP_ACCESS_TOKEN no .env')

# ==================== DB SETUP =====================

Base = declarative_base()

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_user_id = Column(BigInteger, unique=True, nullable=False)
    phone = Column(String, nullable=True)
    api_id = Column(String, nullable=True)
    api_hash = Column(String, nullable=True)
    session_path = Column(String, nullable=True)
    is_authenticated = Column(Boolean, default=False)
    is_banned = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class UserAdminGroup(Base):
    __tablename__ = "user_admin_groups"
    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_user_id = Column(BigInteger, nullable=False, index=True)
    group_id = Column(BigInteger, nullable=False)
    __table_args__ = (UniqueConstraint('telegram_user_id', 'group_id', name='_user_group_uc'),)

class Payment(Base):
    __tablename__ = "payments"
    id = Column(Integer, primary_key=True, autoincrement=True)
    telegram_user_id = Column(BigInteger, nullable=False, index=True)
    plan = Column(String, nullable=False)
    amount = Column(Integer, nullable=False)
    payment_id = Column(String, nullable=True)
    status = Column(String, nullable=False, default="pending")
    expires_at = Column(Date, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

engine = create_async_engine(DATABASE_URL, echo=False, future=True)
AsyncSessionLocal = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

PLANS = {
    "10d": {"label": "10 dias", "amount": 2, "days": 10},
    "1m": {"label": "1 mês", "amount": 20, "days": 30},
    "2m": {"label": "2 meses", "amount": 40, "days": 60},
}
mp_client = mercadopago.SDK(MP_ACCESS_TOKEN)

user_clients = {}
user_group_list = {}
user_settings = {}
active_campaigns = {}
statistics = {'messages_sent': 0, 'active_campaigns': 0}
messages_sent_counter = Counter('messages_sent', 'Total de mensagens enviadas')
active_campaigns_gauge = Gauge('active_campaigns', 'Total de campanhas ativas')
message_forward_time = Summary('message_forward_time_seconds', 'Tempo para encaminhar mensagens')
SESSION_CHECK_INTERVAL = 300  # segundos

# ========== ANTI-FLOOD ==========
FLOOD_LIMIT = 3
FLOOD_INTERVAL = 5
user_flood = {}

def antiflood_check(user_id):
    now = time.time()
    if user_id not in user_flood:
        user_flood[user_id] = []
    user_flood[user_id] = [t for t in user_flood[user_id] if now - t < FLOOD_INTERVAL]
    if len(user_flood[user_id]) >= FLOOD_LIMIT:
        return False
    user_flood[user_id].append(now)
    return True

def antiflood(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        if not antiflood_check(user_id):
            try:
                if update.message:
                    await update.message.reply_text("⏳ Aguarde um pouco antes de enviar outro comando.")
                elif update.callback_query:
                    await update.callback_query.answer("⏳ Aguarde um pouco antes de enviar outro comando.", show_alert=True)
            except Exception:
                pass
            return
        return await func(update, context, *args, **kwargs)
    return wrapper

# ========== CONVERSATION STATES ==========
(
    AUTH_PHONE, AUTH_API_ID, AUTH_API_HASH, AUTH_CODE, AUTH_PASSWORD,
    LINK, INTERVAL, CONFIRM_SESSION_REPLACE
) = range(8)

def get_session_path(telegram_user_id, phone):
    user_dir = SESSIONS_DIR / str(telegram_user_id)
    user_dir.mkdir(exist_ok=True)
    return str(user_dir / f"{phone.replace('+','')}_{telegram_user_id}.session")

def has_active_campaign(user_id):
    return (
        user_id in active_campaigns and
        active_campaigns[user_id]['job'] is not None
    )

def log_error(msg, exc=None):
    print(f"[ERRO] {msg}")
    if exc:
        import traceback
        traceback.print_exc()

def parse_code(text):
    text = text.strip().lower()
    if text.startswith('bot'):
        text = text[3:]
    digits = [d.strip() for d in text.split(',') if d.strip().isdigit()]
    return ''.join(digits)

def is_valid_message_link(link):
    pattern = r'^(https?://)?t\.me/[^/]+/\d+$'
    return re.match(pattern, link) is not None

def is_valid_interval(interval):
    return interval.isdigit() and int(interval) > 0

async def get_user_client(telegram_user_id, session):
    stmt = select(User).where(User.telegram_user_id == telegram_user_id, User.is_authenticated == True)
    result = await session.execute(stmt)
    user = result.scalar_one_or_none()
    if not user or user.is_banned:
        return None
    client = user_clients.get(telegram_user_id)
    if client:
        if not client.is_connected():
            await client.connect()
        if not await client.is_user_authorized():
            await client.disconnect()
            await client.connect()
        return client
    client = TelegramClient(user.session_path, user.api_id, user.api_hash)
    await client.connect()
    user_clients[telegram_user_id] = client
    return client

async def preload_groups_for_user(telegram_user_id, client, context=None):
    if context:
        try:
            await context.bot.send_message(telegram_user_id, "⏳ Carregando grupos, aguarde...")
        except Exception:
            pass
    groups = []
    admin_group_ids = []
    me = await client.get_me()
    async for dialog in client.iter_dialogs():
        if dialog.is_group and not dialog.archived:
            groups.append(dialog.entity)
            try:
                is_admin = await is_user_admin_in_group(client, dialog.entity, me.id)
                if is_admin and hasattr(dialog.entity, "id"):
                    admin_group_ids.append(dialog.entity.id)
            except Exception:
                pass
    user_group_list[telegram_user_id] = groups
    async with AsyncSessionLocal() as session:
        await session.execute(
            UserAdminGroup.__table__.delete().where(UserAdminGroup.telegram_user_id == telegram_user_id)
        )
        for gid in admin_group_ids:
            session.add(UserAdminGroup(telegram_user_id=telegram_user_id, group_id=gid))
        await session.commit()
    if context:
        try:
            await context.bot.send_message(telegram_user_id, f"✅ {len(groups)} grupos carregados com sucesso!\n"
                                                             f"Você é admin em {len(admin_group_ids)} deles.")
        except Exception:
            pass
    return groups

async def is_user_admin_in_group(client, group, user_id):
    try:
        participants = await client.get_participants(group, filter=ChannelParticipantsAdmins)
        admin_ids = {p.id for p in participants}
        return user_id in admin_ids
    except Exception as e:
        log_error("Erro ao checar admin", e)
        return False

def ban_check(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        async with AsyncSessionLocal() as session:
            stmt = select(User).where(User.telegram_user_id == user_id)
            result = await session.execute(stmt)
            user = result.scalar_one_or_none()
            if user and user.is_banned:
                try:
                    if update.message:
                        await update.message.reply_text("🚫 Você está banido do bot. Entre em contato com o suporte.")
                    elif update.callback_query:
                        await update.callback_query.answer("🚫 Você está banido do bot. Entre em contato com o suporte.", show_alert=True)
                except Exception:
                    try:
                        await context.bot.send_message(user_id, "🚫 Você está banido do bot. Entre em contato com o suporte.")
                    except Exception:
                        pass
                return ConversationHandler.END
        return await func(update, context, *args, **kwargs)
    return wrapper

async def session_validation_job(app):
    while True:
        await asyncio.sleep(SESSION_CHECK_INTERVAL)
        async with AsyncSessionLocal() as session:
            stmt = select(User)
            result = await session.execute(stmt)
            users = result.scalars().all()
            for user in users:
                if user.is_authenticated and not user.is_banned:
                    client = user_clients.get(user.telegram_user_id)
                    try:
                        if client and (not await client.is_user_authorized() or not client.is_connected()):
                            print(f"Removendo sessão inválida (user: {user.telegram_user_id})")
                            await client.disconnect()
                            user.is_authenticated = False
                            user_clients.pop(user.telegram_user_id, None)
                            await session.commit()
                            try:
                                await app.bot.send_message(user.telegram_user_id, "⚠️ Sua sessão expirou. É necessário fazer login novamente.")
                            except Exception:
                                pass
                    except Exception as e:
                        user.is_authenticated = False
                        user_clients.pop(user.telegram_user_id, None)
                        await session.commit()

# ========== MERCADO PAGO: MENU DE PLANOS, PAGAMENTO E EXPIRAÇÃO ==========
@ban_check
@antiflood
async def payment_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    keyboard = [
        [InlineKeyboardButton(f"💳 {PLANS['10d']['label']} - R$ {PLANS['10d']['amount']}", callback_data="pay_10d")],
        [InlineKeyboardButton(f"💳 {PLANS['1m']['label']} - R$ {PLANS['1m']['amount']}", callback_data="pay_1m")],
        [InlineKeyboardButton(f"💳 {PLANS['2m']['label']} - R$ {PLANS['2m']['amount']}", callback_data="pay_2m")]
    ]
    await context.bot.send_message(
        user_id,
        "Escolha um plano para liberar o acesso ao bot:",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

async def create_payment(user_id, plan_key):
    plan = PLANS[plan_key]
    preference_data = {
        "items": [{
            "title": f"Plano {plan['label']} - Bot Telegram",
            "quantity": 1,
            "currency_id": "BRL",
            "unit_price": float(plan['amount'])
        }],
        "external_reference": str(user_id)
    }
    preference_response = mp_client.preference().create(preference_data)
    init_point = preference_response["response"]["init_point"]
    payment_id = str(preference_response["response"]["id"])
    return init_point, payment_id

@ban_check
@antiflood
async def payment_button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    plan_key = query.data.replace("pay_", "")
    plan = PLANS[plan_key]
    init_point, payment_id = await create_payment(user_id, plan_key)
    async with AsyncSessionLocal() as session:
        stmt = select(Payment).where(Payment.telegram_user_id == user_id, Payment.status == "pending")
        result = await session.execute(stmt)
        old = result.scalar_one_or_none()
        if old:
            await session.delete(old)
            await session.commit()
        payment = Payment(
            telegram_user_id=user_id,
            plan=plan_key,
            amount=plan["amount"],
            payment_id=payment_id,
            status="pending"
        )
        session.add(payment)
        await session.commit()
    keyboard = [
        [InlineKeyboardButton("💳 Pagar agora (Mercado Pago)", url=init_point)],
        [InlineKeyboardButton("🔄 Já paguei, verificar", callback_data=f"checkpay_{payment_id}")]
    ]
    await query.message.reply_text(
        f"Para liberar o acesso ao bot, pague o plano *{plan['label']}* (R$ {plan['amount']}).\n\n"
        f"1️⃣ Clique no botão abaixo para pagar via Mercado Pago.\n"
        f"2️⃣ Após o pagamento, clique em 'Já paguei, verificar'.\n\n"
        f"Se preferir, copie e cole este link no navegador:\n{init_point}",
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

@ban_check
@antiflood
async def check_payment_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    user_id = update.effective_user.id
    payment_id = query.data.replace("checkpay_", "")
    # Mercado Pago status check
    async with AsyncSessionLocal() as session:
        stmt = select(Payment).where(Payment.payment_id == payment_id, Payment.telegram_user_id == user_id)
        result = await session.execute(stmt)
        payment = result.scalar_one_or_none()
        if not payment:
            await query.answer("Pagamento não encontrado.", show_alert=True)
            return
        # Simulação básica: admin faz verificação manual ou adapte para webhook MP
        status = payment.status
        if status == "approved":
            await query.message.reply_text(
                f"✅ Pagamento aprovado! Seu acesso está liberado até {payment.expires_at.strftime('%d/%m/%Y')}."
            )
            await send_menu(user_id, context)
        else:
            await query.answer("Pagamento ainda não aprovado. Aguarde alguns minutos e tente novamente.", show_alert=True)

async def process_payment_approval(payment_id, user_id, plan_key):
    plan = PLANS[plan_key]
    expires_at = datetime.now().date() + timedelta(days=plan["days"])
    async with AsyncSessionLocal() as session:
        stmt = select(Payment).where(Payment.payment_id == payment_id, Payment.telegram_user_id == user_id)
        result = await session.execute(stmt)
        payment = result.scalar_one_or_none()
        if payment:
            payment.status = "approved"
            payment.expires_at = expires_at
            await session.commit()
        stmt = select(User).where(User.telegram_user_id == user_id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        if user:
            user.is_banned = False
            await session.commit()
    return expires_at

# ========== AVISO DE EXPIRAÇÃO DE PLANO ==========
async def aviso_expiracao_job(app):
    while True:
        await asyncio.sleep(72000)  # a cada 20 horas
        hoje = datetime.now().date()
        aviso_dias = [2,1]
        async with AsyncSessionLocal() as session:
            stmt = select(Payment).where(Payment.status == "approved")
            result = await session.execute(stmt)
            payments = result.scalars().all()
        for pay in payments:
            if pay.expires_at:
                dias_rest = (pay.expires_at - hoje).days
                if dias_rest in aviso_dias:
                    try:
                        await app.bot.send_message(
                            pay.telegram_user_id,
                            f"⏰ Seu plano expira em {dias_rest} dia(s), no dia {pay.expires_at.strftime('%d/%m/%Y')}.\n\nRenove em: Menu > Planos!"
                        )
                    except Exception:
                        pass
                elif dias_rest < 0:
                    try:
                        await app.bot.send_message(
                            pay.telegram_user_id,
                            "🚫 Seu plano expirou. Renove para continuar utilizando o bot!"
                        )
                    except Exception:
                        pass

# ========== AJUSTE NO MENU PRINCIPAL: BOTÃO "PLANOS" ==========
async def send_menu(user_id, context):
    async with AsyncSessionLocal() as session:
        stmt = select(User).where(User.telegram_user_id == user_id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        autenticado = "✅ Sim" if user and user.is_authenticated else "❌ Não"
        campanha = "✅ Ativa" if has_active_campaign(user_id) else "❌ Nenhuma"

    menu_text = (
        "👋 Olá, seja bem-vindo ao *Painel de Campanhas Telethon"
                "📦 *[Ver Planos/Mudar Plano](Acesse pelo botão abaixo)\n"
        "📌 *Status da sua conta:*\n"
        f"• 🔑 Autenticado: {autenticado}\n"
        f"• 🚀 Campanha ativa: {campanha}\n\n"
        "👇 *Escolha uma opção:*"
    )
    keyboard = [
        [
            InlineKeyboardButton("📦 Planos", callback_data='payment_menu')
        ],
        [
            InlineKeyboardButton("🔐 Login", callback_data='login'),
            InlineKeyboardButton("🚀 Nova Campanha", callback_data='create_campaign')
        ],
        [
            InlineKeyboardButton("🛑 Cancelar Campanha", callback_data='cancel_campaign'),
            InlineKeyboardButton("📊 Estatísticas", callback_data='statistics')
        ],
        [
            InlineKeyboardButton("🔄 Atualizar Grupos", callback_data='update_groups'),
            InlineKeyboardButton("❓ Suporte", url=SUPORTE_LINK)
        ]
    ]
    await context.bot.send_photo(
        chat_id=user_id,
        photo=MENU_IMAGE_URL,
        caption=menu_text,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup(keyboard)
    )

# ========== ADMIN PODE VER PAGAMENTOS ==========
async def admin_payments(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        if update.message:
            await update.message.reply_text("Apenas para o admin.")
        return
    async with AsyncSessionLocal() as session:
        stmt = select(Payment)
        result = await session.execute(stmt)
        payments = result.scalars().all()
    lines = []
    for p in payments:
        lines.append(
            f"ID: {p.telegram_user_id} | Plano: {p.plan} | Valor: R${p.amount} | Status: {p.status} | Expira: {p.expires_at}"
        )
    await update.message.reply_text("\n".join(lines) if lines else "Nenhum pagamento registrado.")

# ========== HANDLERS PARA REGISTRAR NO MAIN ==========
def add_payment_handlers(application):
    application.add_handler(CallbackQueryHandler(payment_menu, pattern='^payment_menu$'))
    application.add_handler(CallbackQueryHandler(payment_button_handler, pattern='^pay_'))
    application.add_handler(CallbackQueryHandler(check_payment_handler, pattern='^checkpay_'))
    application.add_handler(CommandHandler("pagamentos", admin_payments))

# ========== DECORATOR DE PAGAMENTO PARA CAMPANHAS ==========
def payment_required(func):
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE, *args, **kwargs):
        user_id = update.effective_user.id
        async with AsyncSessionLocal() as session:
            stmt = select(Payment).where(
                Payment.telegram_user_id == user_id,
                Payment.status == "approved",
                Payment.expires_at >= datetime.now().date()
            )
            result = await session.execute(stmt)
            payment = result.scalar_one_or_none()
            if not payment:
                await payment_menu(update, context)
                return ConversationHandler.END
        return await func(update, context, *args, **kwargs)
    return wrapper

# ========== USO EXEMPLO: Campanha ==========
@ban_check
@antiflood
async def start_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    async with AsyncSessionLocal() as session:
        stmt = select(User).where(User.telegram_user_id == user_id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        if user and user.is_banned:
            await context.bot.send_message(user_id, "🚫 Você está banido do bot. Acesse o suporte se achar injusto.")
            return ConversationHandler.END
        if not (user and user.is_authenticated):
            await context.bot.send_message(user_id, "🚫 Vincule sua conta Telethon antes de iniciar uma campanha! Use o menu.")
            return ConversationHandler.END

    if has_active_campaign(user_id):
        await context.bot.send_message(user_id, "⚠️ Você já tem uma campanha ativa! Cancele antes de iniciar outra.")
        return ConversationHandler.END

    user_settings[user_id] = {"message_link": None, "interval": None}
    await context.bot.send_message(user_id, '📝 Envie o link da mensagem a ser encaminhada:\nExemplo: https://t.me/seucanal/123')
    return LINK

@ban_check
@antiflood
async def set_message_link(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    link = update.message.text.strip()
    if not is_valid_message_link(link):
        await update.message.reply_text("❌ O link informado é inválido. Envie no formato: https://t.me/seucanal/123")
        return LINK
    user_settings[user_id]["message_link"] = link
    await update.message.reply_text("✅ Link salvo! Agora envie o intervalo de minutos entre os envios (exemplo: 15):")
    return INTERVAL

@ban_check
@antiflood
async def set_interval(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    interval = update.message.text.strip()
    if not is_valid_interval(interval):
        await update.message.reply_text("⚠️ Só números inteiros positivos. Exemplo: 10")
        return INTERVAL
    try:
        interval = int(interval)
        async with AsyncSessionLocal() as session:
            client = await get_user_client(user_id, session)
            await preload_groups_for_user(user_id, client, context)
        manage_jobs(context.application.job_queue, user_id, interval)
        user_settings[user_id]["interval"] = interval
        await update.message.reply_text(f"🔁 Intervalo configurado: {interval} minutos\n⚡ Campanha iniciada!")
    except Exception as e:
        log_error("Erro ao iniciar campanha", e)
        await update.message.reply_text(f"❌ Ocorreu um erro ao iniciar sua campanha. Tente novamente ou fale com o suporte.")
        return INTERVAL
    return ConversationHandler.END

def manage_jobs(job_queue, user_id, interval):
    if has_active_campaign(user_id):
        active_campaigns[user_id]['job'].schedule_removal()
        del active_campaigns[user_id]
    job = job_queue.run_repeating(
        forward_message_with_formatting,
        interval=int(interval) * 60,
        first=0,
        data={"user_id": user_id}
    )
    active_campaigns[user_id] = {
        'job': job,
        'start_time': asyncio.get_event_loop().time(),
        'interval': interval
    }
    statistics['active_campaigns'] = len(active_campaigns)
    active_campaigns_gauge.set(len(active_campaigns))
    if user_id not in user_settings:
        user_settings[user_id] = {"message_link": None, "interval": None}

async def get_admin_group_ids(telegram_user_id):
    async with AsyncSessionLocal() as session:
        stmt = select(UserAdminGroup.group_id).where(UserAdminGroup.telegram_user_id == telegram_user_id)
        result = await session.execute(stmt)
        group_ids = [row[0] for row in result.fetchall()]
        return group_ids

@message_forward_time.time()
async def forward_message_with_formatting(context: ContextTypes.DEFAULT_TYPE):
    user_id = context.job.data["user_id"]
    link = user_settings[user_id]["message_link"]
    if not link or user_id not in user_settings or user_id not in user_group_list:
        return

    async with AsyncSessionLocal() as session:
        stmt = select(User).where(User.telegram_user_id == user_id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        if not user or user.is_banned:
            try:
                await context.bot.send_message(user_id, "🚫 Você está banido do bot. Campanha automática encerrada.")
            except Exception:
                pass
            if has_active_campaign(user_id):
                active_campaigns[user_id]['job'].schedule_removal()
                del active_campaigns[user_id]
                statistics['active_campaigns'] = len(active_campaigns)
                active_campaigns_gauge.set(len(active_campaigns))
            return

        client = await get_user_client(user_id, session)
        if not client:
            return
        if user_id not in user_group_list or not user_group_list[user_id]:
            await preload_groups_for_user(user_id, client, context)
        try:
            parts = link.split("/")
            peer = parts[-2]
            msg_id = int(parts[-1])
            entity = None
            try:
                entity = await client.get_entity(peer)
            except Exception:
                pass
            if not entity:
                try:
                    entity = await client.get_entity(link)
                except Exception:
                    pass
            if not entity:
                try:
                    entity = await client.get_entity(int(peer))
                except Exception:
                    pass
            if not entity:
                await context.bot.send_message(user_id, "❌ Não foi possível encontrar o canal/grupo do link informado. Campanha pausada.")
                if has_active_campaign(user_id):
                    active_campaigns[user_id]['job'].schedule_removal()
                    del active_campaigns[user_id]
                    statistics['active_campaigns'] = len(active_campaigns)
                    active_campaigns_gauge.set(len(active_campaigns))
                return
            message = await client.get_messages(entity, ids=msg_id)
            admin_group_ids = await get_admin_group_ids(user_id)
            if not admin_group_ids:
                await context.bot.send_message(user_id, "⚠️ Você não é admin em nenhum grupo para encaminhar a mensagem.")
                return
            tasks = []
            for group in user_group_list[user_id]:
                group_id = group.id if hasattr(group, "id") else group
                if group_id in admin_group_ids:
                    tasks.append(client.forward_messages(group, message))
            if tasks:
                await asyncio.gather(*tasks)
                statistics['messages_sent'] += len(tasks)
                messages_sent_counter.inc(len(tasks))
        except FloodWaitError as e:
            await context.bot.send_message(user_id, f"⏳ Flood control do Telegram. Aguardando {e.seconds} segundos...")
            await asyncio.sleep(e.seconds)
        except PhoneNumberBannedError:
            async with AsyncSessionLocal() as session:
                stmt = select(User).where(User.telegram_user_id == user_id)
                result = await session.execute(stmt)
                user = result.scalar_one_or_none()
                if user:
                    user.is_authenticated = False
                    await session.commit()
            await context.bot.send_message(user_id, "❌ Sua conta foi banida do Telegram. Faça login com outra conta.")
        except MessageIdInvalidError:
            await context.bot.send_message(user_id, "❌ O link configurado não é mais válido. Campanha pausada.")
            if has_active_campaign(user_id):
                active_campaigns[user_id]['job'].schedule_removal()
                del active_campaigns[user_id]
                statistics['active_campaigns'] = len(active_campaigns)
                active_campaigns_gauge.set(len(active_campaigns))
        except ChatAdminRequiredError:
            await context.bot.send_message(user_id, "⚠️ Você perdeu permissão de admin em algum grupo. Campanha pausada.")
            if has_active_campaign(user_id):
                active_campaigns[user_id]['job'].schedule_removal()
                del active_campaigns[user_id]
                statistics['active_campaigns'] = len(active_campaigns)
                active_campaigns_gauge.set(len(active_campaigns))
        except Exception as e:
            log_error("Erro inesperado no encaminhamento", e)
            await context.bot.send_message(user_id, f"❌ Erro inesperado ao encaminhar mensagem. Tente novamente ou fale com o suporte.")

@ban_check
@antiflood
async def cancel_campaign(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if not has_active_campaign(user_id):
        await context.bot.send_message(user_id, "⚠️ Nenhuma campanha ativa para cancelar!")
        return ConversationHandler.END
    active_campaigns[user_id]['job'].schedule_removal()
    del active_campaigns[user_id]
    statistics['active_campaigns'] = len(active_campaigns)
    active_campaigns_gauge.set(len(active_campaigns))
    await context.bot.send_message(user_id, "🛑 Campanha cancelada com sucesso.")
    return ConversationHandler.END

@ban_check
@antiflood
async def show_statistics(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    stats = (
        f"📊 *Estatísticas do Bot:*\n"
        f"• Mensagens enviadas: {statistics['messages_sent']}\n"
        f"• Campanhas ativas: {statistics['active_campaigns']}\n"
    )
    await context.bot.send_message(user_id, stats, parse_mode="Markdown")

async def ban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        if update.message:
            await update.message.reply_text("❌ Você não tem permissão para banir usuários.")
        return

    target_id = None
    if update.message and update.message.reply_to_message:
        target_id = update.message.reply_to_message.from_user.id
    elif context.args:
        arg = context.args[0]
        if arg.startswith("@"):
            username = arg[1:]
            async with AsyncSessionLocal() as session:
                stmt = select(User).where(User.telegram_user_id != None)
                result = await session.execute(stmt)
                users = result.scalars().all()
                for u in users:
                    try:
                        chat = await context.bot.get_chat(u.telegram_user_id)
                        if chat.username and chat.username.lower() == username.lower():
                            target_id = u.telegram_user_id
                            break
                    except Exception:
                        continue
        else:
            try:
                target_id = int(arg)
            except Exception:
                pass

    if not target_id:
        if update.message:
            await update.message.reply_text("Envie: /ban ID_DO_USUARIO ou /ban @username ou responda a uma mensagem do usuário.")
        return

    async with AsyncSessionLocal() as session:
        stmt = select(User).where(User.telegram_user_id == target_id)
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()
        if user:
            user.is_banned = True
            await session.commit()
            if update.message:
                await update.message.reply_text(f"✅ Usuário {target_id} banido com sucesso.")
            try:
                await context.bot.send_message(target_id, "🚫 Você foi banido do bot. Entre em contato com o suporte.")
            except Exception:
                pass
        else:
            if update.message:
                await update.message.reply_text("Usuário não encontrado.")

async def disban_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        if update.message:
            await update.message.reply_text("❌ Você não tem permissão para desbloquear usuários.")
        return
    if not context.args:
        if update.message:
            await update.message.reply_text("Envie: /disban ID_DO_USUARIO")
        return
    try:
        target_id = int(context.args[0])
        async with AsyncSessionLocal() as session:
            stmt = select(User).where(User.telegram_user_id == target_id)
            result = await session.execute(stmt)
            user = result.scalar_one_or_none()
            if user:
                user.is_banned = False
                await session.commit()
                if update.message:
                    await update.message.reply_text(f"✅ Usuário {target_id} desbloqueado com sucesso.")
                try:
                    await context.bot.send_message(target_id, "✅ Sua restrição foi removida. Você tem acesso ao bot novamente.")
                except Exception:
                    pass
            else:
                if update.message:
                    await update.message.reply_text("Usuário não encontrado.")
    except Exception:
        if update.message:
            await update.message.reply_text("Erro ao desbloquear.")

async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    if user_id != OWNER_ID:
        if update.message:
            await update.message.reply_text("❌ Apenas o dono pode ver o painel admin.")
        return
    async with AsyncSessionLocal() as session:
        total_users = await session.execute(select(func.count(User.id)))
        total_users = total_users.scalar()
        total_auth = await session.execute(select(func.count(User.id)).where(User.is_authenticated == True))
        total_auth = total_auth.scalar()
        total_banned = await session.execute(select(func.count(User.id)).where(User.is_banned == True))
        total_banned = total_banned.scalar()
        stmt = select(User)
        result = await session.execute(stmt)
        users = result.scalars().all()
    mem = psutil.virtual_memory()
    meminfo = f"{mem.percent}% ({mem.used // (1024*1024)}MB/{mem.total // (1024*1024)}MB)"
    stats = (
        f"👑 <b>Painel Admin</b>\n"
        f"👤 Usuários cadastrados: {total_users}\n"
        f"🔑 Usuários autenticados: {total_auth}\n"
        f"🚫 Banidos: {total_banned}\n"
        f"📊 Mensagens enviadas: {statistics['messages_sent']}\n"
        f"🚀 Campanhas ativas: {statistics['active_campaigns']}\n"
        f"💾 Memória RAM: {meminfo}\n\n"
        f"👥 <b>Lista de usuários:</b>\n"
    )
    user_lines = []
    for u in users:
        try:
            chat = await context.bot.get_chat(u.telegram_user_id)
            username = f"@{chat.username}" if getattr(chat, "username", None) else "-"
            if hasattr(chat, "full_name"):
                name = chat.full_name
            else:
                first = getattr(chat, "first_name", "")
                last = getattr(chat, "last_name", "")
                name = (first + " " + last).strip() or "-"
        except Exception:
            username = "-"
            name = "-"
        status = []
        if u.is_authenticated:
            status.append("Autenticado")
        if u.is_banned:
            status.append("Banido")
        status_str = ", ".join(status) if status else "Normal"
        user_lines.append(f"• ID: <code>{u.telegram_user_id}</code> | {username} | {name} | {status_str}")

    stats += "\n".join(user_lines) if user_lines else "Nenhum usuário cadastrado ainda."
    if update.message:
        await update.message.reply_text(stats, parse_mode="HTML")

@ban_check
@antiflood
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await send_menu(update.effective_user.id, context)

@ban_check
@antiflood
async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message:
        await update.message.reply_text("❎ Operação cancelada. Voltando ao menu principal.")
    return ConversationHandler.END

# ========== MAIN ==========
async def main():
    start_http_server(2222)
    await init_db()
    job_queue = JobQueue()
    application = ApplicationBuilder().token(BOT_TOKEN).job_queue(job_queue).build()

    # Handlers
    application.add_handler(CommandHandler("ban", ban_cmd))
    application.add_handler(CommandHandler("disban", disban_cmd))
    application.add_handler(CommandHandler("admin", admin_cmd))
    application.add_handler(CommandHandler("pagamentos", admin_payments))
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("cancel", cancel))

    # ConversationHandler de login/campanha (idênticos ao seu original!)
    login_conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_auth, pattern='^login$')],
        states={
            AUTH_PHONE: [MessageHandler(filters.TEXT & ~filters.COMMAND, auth_phone)],
            AUTH_API_ID: [MessageHandler(filters.TEXT & ~filters.COMMAND, auth_api_id)],
            AUTH_API_HASH: [MessageHandler(filters.TEXT & ~filters.COMMAND, auth_api_hash)],
            AUTH_CODE: [MessageHandler(filters.TEXT & ~filters.COMMAND, auth_code)],
            AUTH_PASSWORD: [MessageHandler(filters.TEXT & ~filters.COMMAND, auth_password)],
            CONFIRM_SESSION_REPLACE: [CallbackQueryHandler(confirm_replace_callback, pattern='^replace_session:')]
        },
        fallbacks=[CommandHandler('cancel', cancel)]
    )
    application.add_handler(login_conv_handler)

    campaign_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(start_campaign, pattern='^create_campaign$')],
        states={
            LINK: [MessageHandler(filters.TEXT & ~filters.COMMAND, set_message_link)],
            INTERVAL: [MessageHandler(filters.TEXT & ~filters.COMMAND, set_interval)],
        },
        fallbacks=[CommandHandler('cancel', cancel_campaign)],
    )
    application.add_handler(campaign_conv)

    # Pagamento
    add_payment_handlers(application)

    # Outros botões normais
    application.add_handler(CallbackQueryHandler(cancel_campaign, pattern='^cancel_campaign$'))
    application.add_handler(CallbackQueryHandler(show_statistics, pattern='^statistics$'))
    application.add_handler(CallbackQueryHandler(update_groups, pattern='^update_groups$'))
    application.add_handler(CallbackQueryHandler(inline_menu_handler))

    print("\n" + "="*40)
    print("🚀 BOT INICIADO COM SUCESSO")
    print(f"👤 Admin: {ADMIN_USERNAME}")
    print("📡 Servidor: OK")
    print(f"💾 Banco de dados: Conectado ({'PostgreSQL' if 'postgres' in DATABASE_URL else 'SQLite'})")
    print("📈 Métricas: http://localhost:2222")
    print("="*40 + "\n")

    asyncio.create_task(session_validation_job(application))
    asyncio.create_task(aviso_expiracao_job(application))
    await application.run_polling()

if __name__ == "__main__":
    asyncio.run(main())
    
